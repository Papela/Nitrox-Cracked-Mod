﻿namespace NitroxClient.MonoBehaviours.Gui.Input.KeyBindings.Actions
{
    public abstract class KeyBindingAction
    {
        public abstract void Execute();
    }
}
