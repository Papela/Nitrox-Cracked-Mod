﻿namespace NitroxClient.GameLogic.PlayerLogic.PlayerModel.Abstract
{
    public interface IPlayerModelBuilder
    {
        void Build(INitroxPlayer player);
    }
}
