﻿namespace NitroxClient.GameLogic.Simulation
{
    // Additional metadata that is necessary to process a lock request 
    public interface LockRequestContext
    {
    }
}
